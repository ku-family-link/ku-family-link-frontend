import React from 'react';

export default function BottomBar() {
  return (
    <div className="fixed bottom-0 left-0 w-full h-16 bg-green-200 z-50" />
  );
}